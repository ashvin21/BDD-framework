package org.vmfi.stepDefinitions;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;

import org.vmfi.commonUtility.*;
import org.vmfi.page.commonPage;

public class commonStep extends Base {

	public WebDriver driver;
	commonPage cp;

	@Before
	public void initializerMethods() throws IOException {
		driver = initializeDriver();
		driver.get("https://viewyourdata.education.gov.uk/");
		driver.manage().window().maximize();

	}

	@Given("^I am on \"([^\"]*)\" page$")
	public void i_am_on_something_page(String pageName) {
		cp = new commonPage(driver);
		cp.verifyPageName(pageName);
	}

	@Then("^I See hyperlink \"([^\"]*)\"$")
	public void i_see_hyperlink_something(String hyperlinkName) {
		cp.hyperLinkVerification(hyperlinkName);
	}

	@When("^I see Button \"([^\"]*)\"$")
	public void i_see_button_something(String buttonName) {
		cp.verifyButtonName(buttonName);

	}

	@And("^I click on \"([^\"]*)\" button$")
	public void i_click_on_something_button(String selectedButtonName) {
		cp.selectButton(selectedButtonName);

	}

	@And("^I verify subheading as \"([^\"]*)\"$")
	public void i_verify_subheading_as_something(String subheadingName) {
		cp.subheadingVerification(subheadingName);

	}

	@And("^I click on hyperlink \"([^\"]*)\"$")
	public void i_click_on_hyperlink_something(String selectedHyperLinkName) {
		cp.hyperLinkSelection(selectedHyperLinkName);
	}

	@And("^Switch to (.*) tab$")
	public void handleBrowser(int tabNumber) {
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(tabNumber));
	}

	@After
	public void closingMethods() {

		driver.close();
		driver.quit();

	}

}
