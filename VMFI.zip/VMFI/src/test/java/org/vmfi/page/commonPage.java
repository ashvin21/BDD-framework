package org.vmfi.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class commonPage {

	WebDriver driver;

	public commonPage(WebDriver driver) {
		this.driver = driver;

	}

	private final static String pageNameXpath = "//h1[contains(text(),\"{pagename}\")]";

	private final static String linkNameXpath = "//a[contains(text(),\"{hyperLinkName}\")]";

	private final static String subheadingNameXpath = "//h2[contains(text(),\"{subheadingName}\")]";

	public void verifyPageName(String pagename) {

		String pageName = pageNameXpath.replace("{pagename}", pagename);
		WebElement pageNameElement = driver.findElement(By.xpath(pageName));
		Assert.assertEquals(pageNameElement.getText(), pagename,"Landed on invalid page");
		
	}

	public void hyperLinkVerification(String hyperLinkName) {
		String linkName = linkNameXpath.replace("{hyperLinkName}", hyperLinkName);
		WebElement linkNameElement = driver.findElement(By.xpath(linkName));
		Assert.assertEquals(linkNameElement.getText(),hyperLinkName,"Invalid link name");
	}

	public void hyperLinkSelection(String hyperLinkName) {
		String linkName = linkNameXpath.replace("{hyperLinkName}", hyperLinkName);
		WebElement linkNameElement = driver.findElement(By.xpath(linkName));
		linkNameElement.click();
	}

	public void subheadingVerification(String subheadingName) {
		String subHeadingName = subheadingNameXpath.replace("{subheadingName}", subheadingName);
		WebElement subheadingElement = driver.findElement(By.xpath(subHeadingName));
		Assert.assertEquals(subheadingElement.getText(),subheadingName,"Wrong subheading name");
	}
	
	public void verifyButtonName(String buttonname) {
		String linkName = linkNameXpath.replace("{hyperLinkName}", buttonname);
		WebElement linkNameElement = driver.findElement(By.xpath(linkName));
		Assert.assertEquals(linkNameElement.getText(),buttonname,"Wrong button name");
	}
	
	public void selectButton(String selectbutton) {
		String linkName = linkNameXpath.replace("{hyperLinkName}", selectbutton);
		WebElement linkNameElement = driver.findElement(By.xpath(linkName));
		linkNameElement.click();
	}

}
