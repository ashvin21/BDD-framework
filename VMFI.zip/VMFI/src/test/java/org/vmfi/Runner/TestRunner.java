package org.vmfi.Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
		features = "src/test/resources/Feature",
		tags= {"@Vyed"},
		glue = {"org.vmfi.stepDefinitions","org.vmfi.page","org.vmfi.Listener.ListenersTest"},
		plugin = {"pretty","html:target/HTMLReport/index.html"})

public class TestRunner extends AbstractTestNGCucumberTests {

}
